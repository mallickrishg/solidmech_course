clear
addpath event/

% read file
tic
EV = readndk('jan76_dec17.ndk');
toc

